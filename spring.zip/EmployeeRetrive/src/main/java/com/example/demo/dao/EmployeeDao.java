package com.example.demo.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.example.demo.model.Address;
import com.example.demo.model.Employee;

public interface EmployeeDao {
	public List<Employee> getAllEmployee();

	public Address getAddress(int refId);

//	public void empDelete(int empid);
//
//	public void addressDelete(int refid);
	
	public int deleteEmployee(int empId);

	


}
