package com.example.demo.Mapper;

import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Options;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import com.example.demo.model.Address;
import com.example.demo.model.Employee;

@Mapper
public interface EmployeeMapper {
	String EmpRetrive = "select empid,empname,empmobileno from employee";
	String AddessRetrive = "select refid,hno,state from address where refid=#{refId}";
	String EmpDelete = "delete from employee where empid=#{empid}";
	String AddressDelete = "delete from address where refid=#{refid}";
//	String EmpUpdate = "update employee set empname=#{empname} where empid=#{empid} ";
//	String AddressUpdate = "update address set hno=#{hno} where refid= #{refid}";

	String deleteEmployee = "delete from address where refid=(select empid from employee where empid=#{empId});"
			+ "delete from employee where empid=#{empId};";
	String updateEmployee="update employee set empname=#{empname} where empid=#{empid}";

	@Select(EmpRetrive)
	public List<Employee> getAllEmployee();

	@Select(AddessRetrive)
	public Address getAddress(@Param("refId") int refId);

//	@Delete(EmpDelete)
//	public void empDelete(@Param("empid") int empid);
//
//	@Delete(AddressDelete)
//	public void addressDelete(@Param("refid") int refid);
//	
	@Delete(deleteEmployee)
	public int deleteEmployee(@Param("empId") int empId);

//	@Update(EmpUpdate)
//	public int  empUpdate(@Param("empid") int empid);
//	
//	@Update(AddressUpdate)
//	public int addressUpdate(@Param("refid") int refid);

}
