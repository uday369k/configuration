package com.example.demo.model;

public class Address {
	private int refId;
	private int hno;
	private String State;
	public int getRefId() {
		return refId;
	}
	public void setRefId(int refId) {
		this.refId = refId;
	}
	public int getHno() {
		return hno;
	}
	public void setHno(int hno) {
		this.hno = hno;
	}
	public String getState() {
		return State;
	}
	public void setState(String state) {
		State = state;
	}

}
