package com.example.demo.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.dao.EmployeeDao;
import com.example.demo.model.Address;
import com.example.demo.model.Employee;
import com.example.demo.service.EmployeeService;

@Service
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	private EmployeeDao employeeDao;

	@Override
	@Transactional(rollbackFor = Exception.class)
	public List<Employee> getAllEmployee() {
		List<Employee> allEmployee = employeeDao.getAllEmployee();
		if (allEmployee != null && !allEmployee.isEmpty()) {
			for (Employee employee : allEmployee) {
				Address address = employeeDao.getAddress(employee.getEmpId());
				employee.setAddress(address);
			}
		}
		return allEmployee;
	}

//	@Override
//	@Transactional(rollbackFor = Exception.class)
//	public boolean empDelete(int empid) {
//		employeeDao.empDelete(empid);
//		return true;
//	}

	@Override
	public boolean deleteEmployee(int empId) {
		return employeeDao.deleteEmployee(empId)==1? true :false;
	}

//	@Override
//	public void addressDelete(int refid) {
//		employeeDao.addressDelete(refid);
//		
//	}

}
