package com.example.demo.daoImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.example.demo.Mapper.EmployeeMapper;
import com.example.demo.dao.EmployeeDao;
import com.example.demo.model.Address;
import com.example.demo.model.Employee;

@Repository
public class EmployeeDaoImpl implements EmployeeDao {

	@Autowired
	private EmployeeMapper employeeMapper;

	@Override
	public List<Employee> getAllEmployee() {
		return employeeMapper.getAllEmployee();
	}

	@Override
	public Address getAddress(int refId) {
		return employeeMapper.getAddress(refId);
	}

//	@Override
//	public void empDelete(int empid) {
//		employeeMapper.empDelete(empid);
//
//	}
//
//	@Override
//	public void addressDelete(int refid) {
//		employeeMapper.addressDelete(refid);
//	}

	@Override
	public int deleteEmployee(int empId) {
		return employeeMapper.deleteEmployee(empId);
	}



}
