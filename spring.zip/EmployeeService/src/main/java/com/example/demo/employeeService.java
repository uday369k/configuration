package com.example.demo;

import java.util.Collection;

public class employeeService {

	public static Collection<Employee> findAll() {
		// TODO Auto-generated method stub
		return null;
	}

}
