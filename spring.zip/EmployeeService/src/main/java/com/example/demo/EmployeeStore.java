package com.example.demo;

import java.util.ArrayList;
import java.util.List;

public class EmployeeStore {
 public List<Employee> empStore(){
	 List<Employee> al=new ArrayList<Employee>();
	 al.add(new Employee(1,"aaaa","987456631210"));
	 al.add(new Employee(2,"bbbb","9874663210"));
	 al.add(new Employee(3,"cccc","3214698746"));
	return al;
	 
 }
}
