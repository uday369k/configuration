package com.example.demo.controller;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import org.springframework.boot.autoconfigure.security.oauth2.client.EnableOAuth2Sso;
import org.springframework.util.ObjectUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Employee;

@RestController
@EnableOAuth2Sso
public class controller {
	Map<Integer,Employee> empMap=new HashMap<>();
	
	
	@RequestMapping(value="/employee",method=RequestMethod.GET)
public Collection<Employee> getEmployees(){
	
	if(ObjectUtils.isEmpty(empMap)) {
		empMap.put(120,new Employee(120,"aaa","9874563210"));
		empMap.put(121,new Employee(121,"bbb","8874563210"));
		empMap.put(122,new Employee(122,"ccc","9974563210"));	
	}
	return empMap.values();
	
}
}
