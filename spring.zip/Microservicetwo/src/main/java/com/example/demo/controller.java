package com.example.demo;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class controller {
	
	
	@GetMapping("/two")
	public String getmessage() {
		return "this is from microservicetwo";
		
	}
	
	@GetMapping("/welcome/{name}")
	public String welcomemessage(@PathVariable String name) {
		return "hi"+ name + " this is from welcome message";
	}

}
