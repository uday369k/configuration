package com.example.demo.controller;

import java.security.Principal;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/rest/message")
public class Controller {
	
	
	@GetMapping("/principal")
	public Principal user(Principal principal) {
		return principal;
	}
	@GetMapping
	public String getMessage() {
		return "Hello from OAuth2";
		
	}

}
