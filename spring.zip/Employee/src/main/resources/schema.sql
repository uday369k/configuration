create table employee(
empid serial primary key,
empname text,
empmobileno text
);

create table address(
id serial primary key,
refid int references employee(empid),
hno text,
state text
);