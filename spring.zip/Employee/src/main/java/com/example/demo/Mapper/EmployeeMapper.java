package com.example.demo.Mapper;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Options;

import com.example.demo.model.Address;
import com.example.demo.model.Employee;

@Mapper
public interface EmployeeMapper {
	String storeEmployee = "insert into employee(empName,empMobileno)values(#{empName},#{empMobileNo})";
	String storeAddress ="insert into address(refid,hno,state) values(#{refId},#{hno},#{state})";
	
	
	@Insert(storeEmployee)
	@Options(keyColumn="empid",keyProperty="empId",useGeneratedKeys=true)
	public int storeEmployee(Employee employee);
	
	@Insert(storeAddress)
	public int storeAddress(Address address);
}
