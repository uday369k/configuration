package com.example.demo.model;

public class Address {
	private int refId;
	private String hno;
	private String state;
	
	public int getRefId() {
		return refId;
	}
	public void setRefId(int refId) {
		this.refId = refId;
	}
	public String getHno() {
		return hno;
	}
	public void setHno(String hno) {
		this.hno = hno;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public Address(String hno, String state) {
		super();
		this.hno = hno;
		this.state = state;
	}

}
