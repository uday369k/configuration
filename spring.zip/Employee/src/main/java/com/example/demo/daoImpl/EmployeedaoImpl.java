package com.example.demo.daoImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.example.demo.Mapper.EmployeeMapper;
import com.example.demo.dao.Employeedao;
import com.example.demo.model.Address;
import com.example.demo.model.Employee;

@Repository
public class EmployeedaoImpl implements Employeedao{

	@Autowired
	EmployeeMapper employeeMapper;
	
	@Override
	public int storeEmployee(Employee employee) {
		return employeeMapper.storeEmployee(employee);
	}

	@Override
	public int storeAddress(Address address) {
		// TODO Auto-generated method stub
		return employeeMapper.storeAddress(address);
	}

}
