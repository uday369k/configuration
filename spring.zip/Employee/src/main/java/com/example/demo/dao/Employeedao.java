package com.example.demo.dao;

import com.example.demo.model.Address;
import com.example.demo.model.Employee;

public interface Employeedao {

	public int storeEmployee(Employee employee);

	public int storeAddress(Address address);
}
