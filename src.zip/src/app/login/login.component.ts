import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { RegistrationService } from '../registration.service';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
})
export class LoginComponent implements OnInit {
  login: FormGroup;
  headerName = 'Login Page';
  isUsernotExists = false;
  emailPattern = "^[a-z0-9._%+-]+@[a-z0-9.-]+\.com$";
  // private name = "Login";
  @Output() notify: EventEmitter<String> = new EventEmitter<String>();

  constructor(private formBuilder: FormBuilder, private route: Router, private registrationService: RegistrationService) { }

  ngOnInit() {
    this.login = this.formBuilder.group({
      email: ['', { validators: [Validators.required, Validators.pattern(this.emailPattern)] }],
      password: ['', { validators: [Validators.required, Validators.minLength(6)] }]
    });
  }


  validateLogin() {
    console.log(this.registrationService.registrationDetails);
    // console.log(this.login.get('password').value);
    // console.log(localStorage.getItem('email'));
    // console.log(localStorage.getItem('password'));
    // console.log(JSON.parse(localStorage.getItem('registrationDetails')));
    if (((this.login.get('email').value) === localStorage.getItem('email')) && ((this.login.get('password').value) === (localStorage.getItem('password')))) {
      this.isUsernotExists = false;
      this.route.navigate(['/welcome']);
    }
    else {
      this.isUsernotExists = true;
      let killTimeOut = setTimeout(() => {
        this.isUsernotExists = false;
        clearTimeout(killTimeOut);
      }, 1000)
    }

  }
  navigateToRegistration(): void {
    this.route.navigate(['/registration']);
  }

}

