import { Component } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { PasswordValidator } from './password.validator';
import { RegistrationService } from './registration.service';
import { ActivatedRoute, Router } from '@angular/router'
import { MustMatch } from './MustMatch';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  formDetail: FormGroup;

  constructor(private formBuilder: FormBuilder, private registrationService: RegistrationService, private route: Router) {

  }
  ngOnInit() {
    // this.formDetail = this.formBuilder.group({
    //   firstName: ['', { validators: [Validators.required, Validators.minLength(2), Validators.maxLength(7), Validators.pattern('[a-zA-Z]+')] }],
    //   middleName: [''],
    //   lastName: ['', { validators: [Validators.required, Validators.minLength(2), Validators.maxLength(7), Validators.pattern('[a-zA-Z]+')] }],
    //   email: ['', { validators: [Validators.required, Validators.email] }],
    //   mobile: ['', { validators: [Validators.required, Validators.minLength(10), Validators.maxLength(10), Validators.pattern('[0-9]+')] }],
    //   password: ['', { validators: [Validators.required, Validators.minLength(6)] }],
    //   confirmPassword: ['', { validators: [Validators.required] }]
    // },
    // );
    // console.log(this.route.url);

  }
  onClick(): void {
    this.route.navigate(['/login']);
  }


}