import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

@Injectable()
export class RegistrationService {
  registrationDetails = {};
  create(registration: string) {
    throw new Error("Method not implemented.");
  }
  private url = "http://localhost:3200/register";
  constructor(private http: HttpClient) { }
  // , private registration_com: RegistrationComponent, private route: Router
  register(userData) {
    return this.http.post<any>(this.url, userData);
  }
  // onSubmit() {
  //   if (this.registration_com.formDetail.status === 'VALID' || !this.registration_com.formDetail.errors) {
  //     let registration = this.registration_com.formDetail.value;
  //     localStorage.setItem('registrationDetails', JSON.stringify(registration));
  //     localStorage.setItem('password', this.registration_com.formDetail.get('password').value.trim());
  //     localStorage.setItem('email', this.registration_com.formDetail.get('email').value.trim());
  //     this.route.navigate(['/login']);
  //       this.register(this.registration_com.formDetail.value)
  //         .subscribe(
  //           response => console.log('!Success', response),
  //           error => console.error('!Error', error)
  //         );
  //   }

}


