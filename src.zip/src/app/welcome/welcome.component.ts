import { Component, OnInit } from '@angular/core';
import { Route } from '@angular/compiler/src/core';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-welcome',
  templateUrl: './welcome.component.html',
  styleUrls: ['./welcome.component.css']
})
export class WelcomeComponent implements OnInit {
  public headerName = "Welcome Page";

  constructor(private route: Router) { }

  ngOnInit() {
  }
  onClick(): void {
    this.route.navigate(['/login']);
  }

}
