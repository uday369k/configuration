import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, AbstractControl } from '@angular/forms';
import { PasswordValidator } from '../password.validator';
import { RegistrationService } from '../registration.service';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpClient } from '@angular/common/http'

// import { MustMatch } from '../MustMatch';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']

})
export class RegistrationComponent implements OnInit {
  headerName = "Registration Page";
  formDetail: FormGroup;
  isRegister = false;
  passwordPattern: "^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[$@$!%*?&])[A-Za-z\d$@$!%*?&].{8,}$"
  emailPattern = "[a-z0-9._%+-]+@[a-z0-9.-]+\.com$"

  constructor(private formBuilder: FormBuilder, private registrationService: RegistrationService, private route: Router, private http: HttpClient) {

  }
  ngOnInit() {
    this.formDetail = this.formBuilder.group({
      firstName: ['', { validators: [Validators.required, Validators.minLength(2), Validators.maxLength(7), Validators.pattern('[a-zA-Z]+')] }],
      middleName: ['', Validators.required],
      lastName: ['', { validators: [Validators.required, Validators.minLength(2), Validators.maxLength(10), Validators.pattern('[a-zA-Z]+')] }],
      email: ['', { validators: [Validators.required, Validators.pattern(this.emailPattern)] }],
      mobile: ['', { validators: [Validators.required, Validators.minLength(10), Validators.maxLength(10), Validators.pattern('[0-9]+')] }],
      qualification: ['U.G'],
      password: ['', { validators: [Validators.required, Validators.pattern(this.passwordPattern)] }],
      confirmPassword: ['', { validators: [Validators.required, this.checkConfirmPassword.bind(this)] }],
      gender: ['male']
    },

      // {
      //   validator: MustMatch('password', 'confirmPassword')
      // }
      {
        validator: PasswordValidator
      }

    );

  }

  check() {
    console.log(this.formDetail)
  }

  onSubmit() {

    if (this.formDetail.status === 'VALID' || !this.formDetail.errors) {
      let registration = this.formDetail.value;
      // localStorage.setItem('registrationDetails', JSON.stringify(registration));
      // localStorage.setItem('password', this.formDetail.get('password').value.trim());
      // localStorage.setItem('email', this.formDetail.get('email').value.trim());
      this.registrationService.registrationDetails = registration;
      this.route.navigate(['/login']);
      // this.registrationService.register(this.formDetail.value)
      //   .subscribe(
      //     response => console.log('!Success', response),
      //     error => console.error('!Error', error)
      //   );
      // if (this.isRegister = true) {

      // }
    }

  }
  onClick(): void {
    this.onSubmit();
  }
  checkConfirmPassword(control: AbstractControl) {
    if (this.formDetail && this.formDetail.get('password') && this.formDetail.get('password').value && this.formDetail.get('password').value.trim() !== '' && control && control.value) {
      if (this.formDetail.get('password').value.trim() !== control.value) {
        control.setErrors({ 'passwordsNotMatched': true });
      } else {
        control.setErrors(null);
      }
    }
  }
}
