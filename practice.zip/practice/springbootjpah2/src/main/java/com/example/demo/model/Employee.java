package com.example.demo.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Employee {
	@Id
	private int empid;
	private String empname;
	private double empsalary;

	public int getEmpid() {
		return empid;
	}

	public void setEmpid(int id) {
		this.empid = id;
	}

	public String getEmpname() {
		return empname;
	}

	public void setEmpname(String name) {
		this.empname = name;
	}

	public double getEmpsalary() {
		return empsalary;
	}

	public void setEmpsalary(double salary) {
		this.empsalary = salary;
	}

}
