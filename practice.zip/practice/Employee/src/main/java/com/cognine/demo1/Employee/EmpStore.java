package com.cognine.demo1.Employee;

import java.util.ArrayList;
import java.util.List;

import org.springframework.context.annotation.Configuration;

@Configuration
public class EmpStore {

	public List<EmpData> getEmpData() {
		List<EmpData> al = new ArrayList<EmpData>();
		al.add(new EmpData(1, "aaa", "hyd"));
		al.add(new EmpData(1, "aaa", "hyd"));
		al.add(new EmpData(3, "bbb", "hyd"));
		return al;
	}
}
