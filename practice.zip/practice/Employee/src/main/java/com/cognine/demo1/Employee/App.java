package com.cognine.demo1.Employee;

import java.util.List;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class App {
	@SuppressWarnings({ "resource", "unchecked" })
	public static void main(String[] args)

	{
		AnnotationConfigApplicationContext container = new AnnotationConfigApplicationContext("com");
		// EmpData emp=container.getBean(EmpData.class);
//    	List<EmpData> e=emp.getEmpData();
//   	EmpDisplay ed=container.getBean(EmpDisplay.class);
//    	ed.dispaly();
		EmpStore estore = container.getBean(EmpStore.class);
		List<EmpData> est = estore.getEmpData();
		EmpDisplay ed = container.getBean(EmpDisplay.class);
		ed.dispaly(est);
	}
}