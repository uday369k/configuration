package demo;
import java.util.*;
public class Edata{
int id;
String name;
//void store(int i,String n){
//	id=i;
//	name=n;
//	System.out.println("Employee Data is Stored");
//	Display d=new Display();
//	d.print(i,n);
//}


public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}

}
