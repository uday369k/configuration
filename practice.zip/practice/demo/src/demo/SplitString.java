package demo;

import java.util.*;

public class SplitString {

	public static void main(String[] args) {
		String string = new String("10|1,102,10|3");
		String[] split = string.split(",|2");
		for (String string2 : split) {
			System.out.println(string2);
		}
	}
}
