package demo;

public class StuData {
int rollno;
String name;
double marks;
StuData(int r,String n,double m){
	rollno=r;
	name=n;
	marks=m;
}
}
