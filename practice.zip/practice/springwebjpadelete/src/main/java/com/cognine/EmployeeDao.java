package com.cognine;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

@Repository
public class EmployeeDao {

	@PersistenceContext
	EntityManager entityManager;

	public Employee empDelete() {
		Employee employee=entityManager.find(Employee.class, 1);
	entityManager.remove(employee);
	return employee;
	
	}
}

