package com.cognine;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.ViewResolver;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.view.InternalResourceViewResolver;
@EnableWebMvc
@ComponentScan(basePackages = "com")
@Configuration
public class SpringConfig {
	public ViewResolver viewResolveer() {
		InternalResourceViewResolver  resolver=new InternalResourceViewResolver();
		resolver.setPrefix("/WEB-INF/pages");
		resolver.setSuffix(".jsp");
		return resolver;
		
	}
}