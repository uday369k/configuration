package com.example.demo.dao;

import com.example.demo.model.Employee;

public interface StoreEmployeeDao {
	 int storeEmployee(Employee employee);
	 int deleteEmployee(Integer id);
}
