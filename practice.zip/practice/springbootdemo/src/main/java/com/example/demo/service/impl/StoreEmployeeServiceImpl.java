package com.example.demo.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dao.StoreEmployeeDao;
import com.example.demo.model.Employee;
import com.example.demo.service.StoreEmployeeService;

@Service
public class StoreEmployeeServiceImpl implements StoreEmployeeService{

	@Autowired
	StoreEmployeeDao storeEmployeeDao;
	@Override
	public int storeEmployee(Employee employee) {
		return storeEmployeeDao.storeEmployee(employee);
	}

	@Override
	public int deleteEmployee(Integer id) {
		return storeEmployeeDao.deleteEmployee(id);
	}

}
