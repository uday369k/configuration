package com.example.demo.dao.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.example.demo.dao.StoreEmployeeDao;
import com.example.demo.model.Employee;
import com.example.demo.repository.StoreEmloyeeRepository;

@Repository
public class StoreEmpoyeeDaoImpl implements StoreEmployeeDao{

	@Autowired
	StoreEmloyeeRepository storeEmloyeeRepository;
	@Override
	public int storeEmployee(Employee employee) {
		int returnVal=-1;
		Employee save = storeEmloyeeRepository.save(employee);
		if (save!=null) {
			returnVal=1;
		}
		return returnVal;
	}

	@Override
	public int deleteEmployee(Integer id) {
		storeEmloyeeRepository.deleteById(id);
		return 1;
	}

}
