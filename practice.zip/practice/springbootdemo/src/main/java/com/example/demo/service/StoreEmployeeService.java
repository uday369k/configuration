package com.example.demo.service;

import com.example.demo.model.Employee;

public interface StoreEmployeeService {
	 int storeEmployee(Employee employee);
	 int deleteEmployee(Integer id);
}
