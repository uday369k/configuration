package com.example.demo.dao;

import com.example.demo.model.Employee;

public interface EmployeeDao {
	public int update(Employee employee);

}
