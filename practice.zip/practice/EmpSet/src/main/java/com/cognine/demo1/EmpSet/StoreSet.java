package com.cognine.demo1.EmpSet;

import java.util.HashSet;
import java.util.Set;

import org.springframework.context.annotation.Configuration;
@Configuration
public class StoreSet {
	public Set<EmpSet> getEmpSet(){
		Set<EmpSet> set=new HashSet<EmpSet>();
		set.add(new EmpSet(1,"aaaa","987456321"));
		set.add(new EmpSet(2,"bbbb","321456987"));
		set.add(new EmpSet(3,null,"369874521"));
		return set;
	}
	public void display(Set<EmpSet> set) {
		for(EmpSet x : set) {
		System.out.println(x);
	}
	}
}