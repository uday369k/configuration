package com.cognine.demo1.EmpSet;

import java.util.Set;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
       AnnotationConfigApplicationContext container=new AnnotationConfigApplicationContext("com");
       StoreSet s=container.getBean(StoreSet.class);
       Set<EmpSet> e=s.getEmpSet();
       s.display(e);
    }
}
