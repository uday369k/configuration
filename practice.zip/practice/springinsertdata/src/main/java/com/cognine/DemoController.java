package com.cognine;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class DemoController {
	@Autowired
	EmployeeDao employeeDao;

	@RequestMapping(path = "/home", method = RequestMethod.GET)
	public ResponseEntity<Employee> goHomePage() {
		Employee employee = new Employee();
		employee.setEmpid(1);
		employee.setEmpname("venu");
		employee.setEmpsalary(1234.5);
		return new ResponseEntity<Employee>(employee, HttpStatus.OK);
	}
	
//	@GetMapping(path = "/getallemplopyees")
//	public ResponseEntity<List<Employee>> getAllEmployees() {
//	List<Employee> allEmployeeDetails = employeeDao.getAllEmployeeDetails();
//		return new ResponseEntity<List<Employee>>(allEmployeeDetails, HttpStatus.OK);
//	} 


//	public String goHomePage() {
//		return "hai";
//	}
}
