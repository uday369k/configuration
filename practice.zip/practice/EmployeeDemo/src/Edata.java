public class Edata{
int id;
String name;
void Store(int i,String n){
	id=i;
	name=n;
	System.out.println("Employee Data is Stored");
	Dispaly d=new Display();
	d.print(i,d);
}
}
