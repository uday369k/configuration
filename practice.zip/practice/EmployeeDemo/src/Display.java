public class Display {
	void print(int a,int b){
		System.out.println("Employee Details are:");
		System.out.println(a+" "+b); 
	}

}
