import java.util.*;
public class EmployeeDemo extends Edata{

	public static void main(String[] args) {
	Scanner sc=new Scanner();
	System.out.println("enter employee no:");
	int m=sc.nextInt();
	System.out.println("enter employee name:");
	String n=sc.nextLine();
	Edata e=new Edata();
	e.store(m,n);
	}

}
