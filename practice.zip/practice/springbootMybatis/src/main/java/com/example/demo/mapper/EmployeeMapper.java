package com.example.demo.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import com.example.demo.model.Employee;

@Mapper
public interface EmployeeMapper {
//	@Insert("insert into employee(empname,empsalary) values(#{empname},#{empsalary})")
//	@SelectKey(statement="SELECT LAST_INSERT_ID()", keyProperty="id", before=false,resultType=Integer.class)
//	void insert(Employee employee);

	@Select("select * from employee")
	List<Employee> findAll();

}
