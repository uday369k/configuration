package com.cognine.demo.MultipleInsert;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

/**
 * Hello world!
 *
 */
public class App {
	public static void main( String[] args )
    {
     @SuppressWarnings("resource")
	AnnotationConfigApplicationContext container=new AnnotationConfigApplicationContext("com");
     EmloyeeData emloyeeData = container.getBean(EmloyeeData.class);
    InsertData insertData = container.getBean(InsertData.class);
//     UpdateRecords updateRecords=container.getBean(UpdateRecords.class);
    insertData.insertData(emloyeeData.getEmpData());
//     updateRecords.updateData(emloyeeData.getEmpData());
     System.out.println("venu");

    }
}
