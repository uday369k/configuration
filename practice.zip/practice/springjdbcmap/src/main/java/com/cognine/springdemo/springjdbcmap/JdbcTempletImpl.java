package com.cognine.springdemo.springjdbcmap;

public class JdbcTempletImpl {

}
