package com.cognine.springdemo.springjdbcmap;

public class DataSourceImpl {

}
