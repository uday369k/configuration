package com.cognine.springjpa;

import java.util.List;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

/**
 * Hello world!
 *
 */
public class App {
	@SuppressWarnings("resource")
	public static void main(String[] args) {
		AnnotationConfigApplicationContext container = new AnnotationConfigApplicationContext("com");
		EmployeeDao employeeDao = container.getBean(EmployeeDao.class);
//		Employee employee = new Employee();
//		employee.setId(1);
//		employee.setEmpSalary(123456.3);
//		employee.setEmpName("aaaaa");
//		employeeDao.insertEmployee(employee);
//		
		List<Employee> allEmployeeDetails = employeeDao.getAllEmployeeDetails();
		for (Employee employee2 : allEmployeeDetails) {
			System.out.println(employee2);
		}
	}
}
