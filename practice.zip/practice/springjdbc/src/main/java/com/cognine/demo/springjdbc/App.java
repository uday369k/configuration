package com.cognine.demo.springjdbc;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.text.html.AccessibleHTML.TableElementInfo.TableAccessibleContext;

import org.springframework.beans.factory.parsing.EmptyReaderEventListener;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.RowMapperResultSetExtractor;

/**
 * Hello world!
 *
 */
public class App {
	@SuppressWarnings("resource")
	public static void main(String[] args) {
		AnnotationConfigApplicationContext container = new AnnotationConfigApplicationContext("com");
		JdbcTemplate jdbcTemplate = container.getBean(JdbcTemplate.class);
		jdbcTemplate.update(create Table emp(empid Number(10),empname varchar(20)));
//		jdbcTemplate.update("insert into employee(empname,empsalary,empid) values('aaaa','100000',10)");
//		jdbcTemplate.update("delete from employee where empid=8");
//		List<Employee> listOfEmployee = jdbcTemplate.query("select * from employee where empid=4",
//				new ResultSetExtractor<List<Employee>>() {
//					public List<Employee> extractData(ResultSet rs) throws SQLException, DataAccessException {
//						List<Employee> listOfEmployee = new ArrayList<Employee>();
//						while (rs.next()) {
//							Employee employee = new Employee();
//							employee.setId(rs.getInt("empid"));
//							employee.setName(rs.getString("empname"));
//							employee.setSalary(rs.getDouble("empsalary"));
//							listOfEmployee.add(employee);
//						}
//						return listOfEmployee;
//					}
//
//				});
//		List<Employee> listOfEmployee=jdbcTemplate.query("select * from employee", 
//				new RowMapper<Employee>() {
//			public Employee mapRow(ResultSet rs,int rownumber)throws SQLException{
//				Employee emp = new Employee();
//				emp.setId(rs.getInt("empid"));
//				emp.setName(rs.getString("empname"));
//				emp.setSalary(rs.getDouble("empsalary"));
//				return emp;
//			}
//		}
//				);
//
//		for (Employee employee : listOfEmployee) {
//			System.out.println(employee);
//		}
//
//		List<Employee> listOfEmployees = jdbcTemplate.query("select * from employee", new RowMapper<Employee>() {
//
//			public Employee mapRow(ResultSet rs, int rowNum) throws SQLException {
//				Employee employee = new Employee();
//				employee.setId(rs.getInt("empid"));
//				employee.setName(rs.getString("empname"));
//				employee.setSalary(rs.getDouble("empsalary"));
//				return employee;
//			}
//
//		});
//		
//		for (Employee employee : listOfEmployees) {
//			System.out.println(employee);
//		}
	}
}
