package com.example.demo.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Options;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import com.example.demo.model.Address;
import com.example.demo.model.Student;

@Mapper
public interface StudentMapper {

	public static final String STORE_STUDENT="insert into student(sName,sCollege)"
			+ "values(#{sName},#{sCollege})";
	
	public static final String STORE_ADDRESS="insert into address(refId,pState,pCountry)"
			+ "values(#{refId},#{pState},#{pCountry})";
	
	@Insert(STORE_STUDENT)
	@Options(keyColumn="id",keyProperty="id",useGeneratedKeys=true)
	public int storeStudent(Student student);
	
	@Insert(STORE_ADDRESS)
	public int storeAddress(Address address);
	
	public static final String GET_STUDENT="select * from student";
	
	public static final String GET_ADDRESS="select * from address where refId=#{refId}";
	
	@Select(GET_STUDENT)
	public List<Student> getStudent();
	
	@Select(GET_ADDRESS)
	public List<Address> getAddress(@Param("refId") int refId);
}
