package com.example.demo.ServiceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Dao.StudentDao;
import com.example.demo.Service.StudentService;
import com.example.demo.model.Address;
import com.example.demo.model.Student;

@Service
public class StudentServiceImpl implements StudentService {

	@Autowired
	StudentDao studentDao;
	
	@Override
	public boolean storeStudentDetails(List<Student> listofstudents) {
		boolean isStored=false;
		if(listofstudents!=null && !listofstudents.isEmpty())
		{
			for (Student student : listofstudents) {
				studentDao.storeStudent(student);
				List<Address> listofaddress=student.getAddress();
				if(listofaddress!=null && !listofaddress.isEmpty())
				{
					for (Address address : listofaddress) {
						address.setRefId(student.getId());
						studentDao.storeAddress(address);
					}
				}
			}
			isStored=true;
		}
		return isStored;
	}

	@Override
	public List<Student> getAllStudents() {
		
		List<Student> listofstudents=studentDao.getStudent();
		for (Student student : listofstudents) {
			student.setAddress(studentDao.getAddress(student.getId()));
		}
		return listofstudents;
	}

}
