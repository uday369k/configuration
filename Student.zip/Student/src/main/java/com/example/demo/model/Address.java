package com.example.demo.model;

public class Address {

	private int refId;
	private String pState;
	private String pCountry;
	public int getRefId() {
		return refId;
	}
	public void setRefId(int refId) {
		this.refId = refId;
	}
	public String getpState() {
		return pState;
	}
	public void setpState(String pState) {
		this.pState = pState;
	}
	public String getpCountry() {
		return pCountry;
	}
	public void setpCountry(String pCountry) {
		this.pCountry = pCountry;
	}
	@Override
	public String toString() {
		return "Address [refId=" + refId + ", pState=" + pState + ", pCountry=" + pCountry + "]";
	}
	
}
