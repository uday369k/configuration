package com.example.demo.DaoImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.example.demo.Dao.StudentDao;
import com.example.demo.mapper.StudentMapper;
import com.example.demo.model.Address;
import com.example.demo.model.Student;

@Repository
public class StudentDaoImpl implements StudentDao{

	@Autowired
	StudentMapper studentMapper;
	
	@Override
	public int storeStudent(Student student) {
	
		return studentMapper.storeStudent(student);
	}

	@Override
	public int storeAddress(Address address) {
	
		return studentMapper.storeAddress(address);
	}

	@Override
	public List<Student> getStudent() {
		
		return studentMapper.getStudent();
	}

	@Override
	public List<Address> getAddress(int id) {
		
		return studentMapper.getAddress(id);
	}

}
