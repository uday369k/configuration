package com.example.demo.model;

import java.util.List;

public class Student {

	private int id;
	private String sName;
	private String sCollege;
	private List<Address> address;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getsName() {
		return sName;
	}
	public void setsName(String sName) {
		this.sName = sName;
	}
	public String getsCollege() {
		return sCollege;
	}
	public void setsCollege(String sCollege) {
		this.sCollege = sCollege;
	}
	public List<Address> getAddress() {
		return address;
	}
	public void setAddress(List<Address> address) {
		this.address = address;
	}
	@Override
	public String toString() {
		return "Student [id=" + id + ", sName=" + sName + ", sCollege=" + sCollege + ", address=" + address + "]";
	}
}
