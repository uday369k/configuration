package com.example.demo.Service;

import java.util.List;

import com.example.demo.model.Student;

public interface StudentService {

	public boolean storeStudentDetails(List<Student> listofstudents);
	
	public List<Student> getAllStudents();
}
