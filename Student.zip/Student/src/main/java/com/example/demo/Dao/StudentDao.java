package com.example.demo.Dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import com.example.demo.model.Address;
import com.example.demo.model.Student;

public interface StudentDao {

    public int storeStudent(Student student);
	
	public int storeAddress(Address address);
	
	public List<Student> getStudent();
	
	public List<Address> getAddress(@Param("id") int id);
}
